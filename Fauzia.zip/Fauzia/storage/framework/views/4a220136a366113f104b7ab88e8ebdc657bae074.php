

<?php $__env->startSection('content'); ?>
<div class="container" style="padding-top: 40px; padding-bottom:40px; min-height: 600px">
    <div class="card">
        <div class="card-body">
            <p class="card-text">
                <div class="card-title"><h5>Data Pengguna</h5></div>
                <a href="<?php echo e(route('user.create')); ?>">
                    <button class="btn btn-sm btn-success">Tambah</button>
                </a>
                <p></p>
                <table class="table table-striped">
                    <tr>
                        <th>Email</th>
                        <th>Nama</th>
                        <th>Aksi</th>
                    </tr>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->email); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td style="width: 25%">
                            <a href="<?php echo e(route('user.edit', $item->id)); ?>">
                                <button class="btn btn-sm btn-warning">Edit</button>
                            </a>
                            <form action="<?php echo e(route('user')); ?>" method="POST" style="display: inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <input type="text" name="id" value="<?php echo e($item->id); ?>" style="display:none">
                                <button class="btn btn-sm btn-danger" name="hapus">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\tugas-4-web\Adam Syahputra\resources\views/apps/user/index.blade.php ENDPATH**/ ?>